import { IonicNativePlugin } from '@ionic-native/core';
export declare class UploadFile extends IonicNativePlugin {
    /**
     *开始上传
     *
     * @param {*} params
     * @param {*} onSuccess
     * @param {*} onError
     * @returns {void}
     * @memberof UploadFile
     */
    startUploadFile(params: object[], onSuccess: Function, onError: Function): void;
    pauseUploadFile(params: object[], onSuccess: Function, onError: Function): void;
    resumeUploadFile(params: object[], onSuccess: Function, onError: Function): void;
    cancelUploadFile(params: object[], onSuccess: Function, onError: Function): void;
}
