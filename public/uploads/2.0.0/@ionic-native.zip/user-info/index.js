var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from "@angular/core";
import { Cordova, IonicNativePlugin, Plugin } from "@ionic-native/core";
var UserInfo = (function (_super) {
    __extends(UserInfo, _super);
    function UserInfo() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    UserInfo.prototype.setUserInfo = function (tenantId, userNO, userCode, authority) {
        return;
    };
    UserInfo.decorators = [
        { type: Injectable },
    ];
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String, String, String, Object]),
        __metadata("design:returntype", Promise)
    ], UserInfo.prototype, "setUserInfo", null);
    UserInfo = __decorate([
        Plugin({
            pluginName: "UserInfo",
            plugin: "com.exe.CDVUserInfoPlugin",
            // npm package name, example: cordova-plugin-camera
            // pluginRef: "plugins.CDVUserInfoPlugin", // the variable reference to call the plugin, example: navigator.geolocation
            pluginRef: "exe.UserInfo",
            // the variable reference to call the plugin, example: navigator.geolocation
            repo: "http://192.168.30.8:10080/exe-front/cordova-plugins/tree/master/com.exe.CDVUserInfoPlugin",
            // the github repository URL for the plugin
            install: "",
            // OPTIONAL install command, in case the plugin requires variables
            installVariables: [],
            // OPTIONAL the plugin requires variables
            platforms: ["iOS"] // Array of platforms supported, example: ['Android', 'iOS']
        })
    ], UserInfo);
    return UserInfo;
}(IonicNativePlugin));
export { UserInfo };
//# sourceMappingURL=index.js.map