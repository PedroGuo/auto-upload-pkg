import { IonicNativePlugin } from "@ionic-native/core";
export declare class UserInfo extends IonicNativePlugin {
    setUserInfo(tenantId: string, userNO: string, userCode: string, authority: any): Promise<any>;
}
