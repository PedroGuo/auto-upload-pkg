import { IonicNativePlugin } from "@ionic-native/core";
export interface CaptureVideoOptions {
    limit: number;
    duration: number;
    highquality: boolean;
    frontcamera: boolean;
    portraitOverlay?: string;
    landscapeOverlay?: string;
    overlayText?: string;
    video_length?: number;
    video_length_min?: number;
}
export declare class VideoCapturePlus extends IonicNativePlugin {
    captureVideo(options: CaptureVideoOptions): Promise<any>;
}
