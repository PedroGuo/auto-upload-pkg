import { IonicNativePlugin } from "@ionic-native/core";
export interface TagsOptions {
    sequence: number;
    tag?: string;
    tags?: string[];
}
export interface AliasOptions {
    sequence: number;
    alias?: string;
}
/**
 * 注意：该IonicNativePlugin并未实现所有的方法
 */
export declare class JPush extends IonicNativePlugin {
    init(): void;
    stopPush(): void;
    resumePush(): void;
    clearLocalNotifications(): void;
    getRegistrationID(): Promise<any>;
    isPushStopped(): Promise<any>;
    setTags(options: TagsOptions): Promise<any>;
    addTags(options: TagsOptions): Promise<any>;
    deleteTags(options: TagsOptions): Promise<any>;
    cleanTags(options: TagsOptions): Promise<any>;
    getAllTags(options: TagsOptions): Promise<any>;
    checkTagBindState(options: TagsOptions): Promise<any>;
    setAlias(options: AliasOptions): Promise<any>;
    deleteAlias(options: AliasOptions): Promise<any>;
    getAlias(options: AliasOptions): Promise<any>;
    getUserNotificationSettings(): Promise<any>;
    startJPushSDK(): void;
    setBadge(): void;
    resetBadge(): void;
    setDebugModeFromIos(): void;
    setLogOFF(): void;
    setCrashLogON(): void;
    clearAllLocalNotifications(): void;
    setLocation(latitude: number, longitude: number): void;
    startLogPageView(pageName: string): void;
    stopLogPageView(pageName: string): void;
    setApplicationIconBadgeNumber(badge: number): void;
    getApplicationIconBadgeNumber(): Promise<any>;
    getConnectionState(): Promise<any>;
    setBasicPushNotificationBuilder(): Promise<any>;
    clearAllNotification(): void;
    clearNotificationById(id: number): void;
}
