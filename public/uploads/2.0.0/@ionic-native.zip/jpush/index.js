var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from "@angular/core";
import { Cordova, IonicNativePlugin, Plugin } from "@ionic-native/core";
/**
 * 注意：该IonicNativePlugin并未实现所有的方法
 */
var JPush = (function (_super) {
    __extends(JPush, _super);
    function JPush() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    JPush.prototype.init = function () { };
    JPush.prototype.stopPush = function () { };
    JPush.prototype.resumePush = function () { };
    JPush.prototype.clearLocalNotifications = function () { };
    JPush.prototype.getRegistrationID = function () {
        return;
    };
    JPush.prototype.isPushStopped = function () {
        return;
    };
    /**
     * 设置标签。
     * 注意：该接口是覆盖逻辑，而不是增量逻辑。即新的调用会覆盖之前的设置。
     * @param params = { 'sequence': number, 'tags': ['tag1', 'tag2'] }
     */
    JPush.prototype.setTags = function (options) {
        return;
    };
    /**
     * 新增标签。
     * @param params = { 'sequence': number, 'tags': ['tag1', 'tag2'] }
     */
    JPush.prototype.addTags = function (options) {
        return;
    };
    /**
     * 删除指定标签。
     * @param params = { 'sequence': number, 'tags': ['tag1', 'tag2'] }
     */
    JPush.prototype.deleteTags = function (options) {
        return;
    };
    /**
     * 清除所有标签。
     * @param params = { 'sequence': number }
     */
    JPush.prototype.cleanTags = function (options) {
        return;
    };
    /**
     * 查询所有标签。
     * @param params = { 'sequence': number }
     */
    JPush.prototype.getAllTags = function (options) {
        return;
    };
    /**
     * 查询指定标签与当前用户的绑定状态。
     * @param params = { 'sequence': number, 'tag': string }
     */
    JPush.prototype.checkTagBindState = function (options) {
        return;
    };
    /**
     * 设置别名。
     * 注意：该接口是覆盖逻辑，而不是增量逻辑。即新的调用会覆盖之前的设置。
     * @param params = { 'sequence': number, 'alias': string }
     */
    JPush.prototype.setAlias = function (options) {
        return;
    };
    /**
     * 删除别名。
     * @param params = { 'sequence': number }
     */
    JPush.prototype.deleteAlias = function (options) {
        return;
    };
    /**
     * 查询当前绑定的别名。
     * @param params = { 'sequence': number }
     */
    JPush.prototype.getAlias = function (options) {
        return;
    };
    // 判断系统设置中是否对本应用启用通知。
    // iOS: 返回值如果大于 0，代表通知开启；0: 通知关闭。
    // UIRemoteNotificationTypeNone = 0,
    // UIRemoteNotificationTypeBadge = 1 << 0,
    // UIRemoteNotificationTypeSound = 1 << 1,
    // UIRemoteNotificationTypeAlert = 1 << 2,
    // UIRemoteNotificationTypeNewsstandContentAvailability = 1 << 3,
    // Android: 返回值 1 代表通知启用；0: 通知关闭。
    JPush.prototype.getUserNotificationSettings = function () {
        return;
    };
    JPush.prototype.startJPushSDK = function () { };
    JPush.prototype.setBadge = function () { };
    JPush.prototype.resetBadge = function () { };
    JPush.prototype.setDebugModeFromIos = function () { };
    JPush.prototype.setLogOFF = function () { };
    JPush.prototype.setCrashLogON = function () { };
    JPush.prototype.clearAllLocalNotifications = function () { };
    JPush.prototype.setLocation = function (latitude, longitude) { };
    JPush.prototype.startLogPageView = function (pageName) { };
    JPush.prototype.stopLogPageView = function (pageName) { };
    JPush.prototype.setApplicationIconBadgeNumber = function (badge) { };
    JPush.prototype.getApplicationIconBadgeNumber = function () {
        return;
    };
    JPush.prototype.getConnectionState = function () {
        return;
    };
    JPush.prototype.setBasicPushNotificationBuilder = function () {
        return;
    };
    JPush.prototype.clearAllNotification = function () { };
    JPush.prototype.clearNotificationById = function (id) { };
    JPush.decorators = [
        { type: Injectable },
    ];
    __decorate([
        Cordova({
            sync: true
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "init", null);
    __decorate([
        Cordova({
            sync: true
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "stopPush", null);
    __decorate([
        Cordova({
            sync: true
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "resumePush", null);
    __decorate([
        Cordova({
            sync: true
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "clearLocalNotifications", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "getRegistrationID", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "isPushStopped", null);
    __decorate([
        Cordova()
        /**
         * 设置标签。
         * 注意：该接口是覆盖逻辑，而不是增量逻辑。即新的调用会覆盖之前的设置。
         * @param params = { 'sequence': number, 'tags': ['tag1', 'tag2'] }
         */
        ,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "setTags", null);
    __decorate([
        Cordova()
        /**
         * 新增标签。
         * @param params = { 'sequence': number, 'tags': ['tag1', 'tag2'] }
         */
        ,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "addTags", null);
    __decorate([
        Cordova()
        /**
         * 删除指定标签。
         * @param params = { 'sequence': number, 'tags': ['tag1', 'tag2'] }
         */
        ,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "deleteTags", null);
    __decorate([
        Cordova()
        /**
         * 清除所有标签。
         * @param params = { 'sequence': number }
         */
        ,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "cleanTags", null);
    __decorate([
        Cordova()
        /**
         * 查询所有标签。
         * @param params = { 'sequence': number }
         */
        ,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "getAllTags", null);
    __decorate([
        Cordova()
        /**
         * 查询指定标签与当前用户的绑定状态。
         * @param params = { 'sequence': number, 'tag': string }
         */
        ,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "checkTagBindState", null);
    __decorate([
        Cordova()
        /**
         * 设置别名。
         * 注意：该接口是覆盖逻辑，而不是增量逻辑。即新的调用会覆盖之前的设置。
         * @param params = { 'sequence': number, 'alias': string }
         */
        ,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "setAlias", null);
    __decorate([
        Cordova()
        /**
         * 删除别名。
         * @param params = { 'sequence': number }
         */
        ,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "deleteAlias", null);
    __decorate([
        Cordova()
        /**
         * 查询当前绑定的别名。
         * @param params = { 'sequence': number }
         */
        ,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "getAlias", null);
    __decorate([
        Cordova()
        // 判断系统设置中是否对本应用启用通知。
        // iOS: 返回值如果大于 0，代表通知开启；0: 通知关闭。
        // UIRemoteNotificationTypeNone = 0,
        // UIRemoteNotificationTypeBadge = 1 << 0,
        // UIRemoteNotificationTypeSound = 1 << 1,
        // UIRemoteNotificationTypeAlert = 1 << 2,
        // UIRemoteNotificationTypeNewsstandContentAvailability = 1 << 3,
        // Android: 返回值 1 代表通知启用；0: 通知关闭。
        ,
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "getUserNotificationSettings", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "startJPushSDK", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "setBadge", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "resetBadge", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "setDebugModeFromIos", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "setLogOFF", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "setCrashLogON", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "clearAllLocalNotifications", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, Number]),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "setLocation", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String]),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "startLogPageView", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String]),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "stopLogPageView", null);
    __decorate([
        Cordova({
            sync: true,
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number]),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "setApplicationIconBadgeNumber", null);
    __decorate([
        Cordova({
            platforms: ["iOS"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "getApplicationIconBadgeNumber", null);
    __decorate([
        Cordova({
            platforms: ["Android"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "getConnectionState", null);
    __decorate([
        Cordova({
            platforms: ["Android"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], JPush.prototype, "setBasicPushNotificationBuilder", null);
    __decorate([
        Cordova({
            platforms: ["Android"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "clearAllNotification", null);
    __decorate([
        Cordova({
            platforms: ["Android"]
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number]),
        __metadata("design:returntype", void 0)
    ], JPush.prototype, "clearNotificationById", null);
    /**
     * 注意：该IonicNativePlugin并未实现所有的方法
     */
    JPush = __decorate([
        Plugin({
            pluginName: "JPush",
            plugin: "jpush-phonegap-plugin",
            // npm package name, example: cordova-plugin-camera
            // pluginRef: "JPush", // the variable reference to call the plugin, example: navigator.geolocation
            pluginRef: "exe.JPush",
            // the variable reference to call the plugin, example: navigator.geolocation
            repo: "https://github.com/jpush/jpush-phonegap-plugin",
            // the github repository URL for the plugin
            install: "cordova plugin add jpush-phonegap-plugin --variable APP_KEY=your_jpush_appkey",
            // OPTIONAL install command, in case the plugin requires variables
            installVariables: ["APP_KEY"],
            // OPTIONAL the plugin requires variables
            platforms: ["Android", "iOS"] // Array of platforms supported, example: ['Android', 'iOS']
        })
    ], JPush);
    return JPush;
}(IonicNativePlugin));
export { JPush };
//# sourceMappingURL=index.js.map