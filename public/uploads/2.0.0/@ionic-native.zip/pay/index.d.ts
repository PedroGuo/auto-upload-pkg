import { IonicNativePlugin } from "@ionic-native/core";
export interface ExePayCallParams {
    tx_no: string;
    type: string;
    body?: string;
    orderId?: string;
}
export interface ExePayOptions {
    tradeNo: string;
    type: string;
    body?: string;
    orderId?: string;
    successCallback?: Function;
    errorCallback?: Function;
}
export declare class Pay extends IonicNativePlugin {
    Pay(params: ExePayOptions): void;
}
