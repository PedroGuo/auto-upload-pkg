export var messageType;
(function (messageType) {
    messageType["txt"] = "txt";
    messageType["loc"] = "loc";
    messageType["rich"] = "rich";
    messageType["voc"] = "voc";
    messageType["img"] = "img";
    messageType["contact"] = "contact";
    messageType["other"] = "other";
})(messageType || (messageType = {}));
export var openNativeAction;
(function (openNativeAction) {
    openNativeAction["openConversation"] = "openConversation";
    openNativeAction["createGroup"] = "createGroup";
    openNativeAction["addFriend"] = "addFriend";
    openNativeAction["openContact"] = "openContact";
    openNativeAction["createConversation"] = "createConversation";
    openNativeAction["popToNative"] = "popToNative";
    openNativeAction["searchText"] = "searchText";
    openNativeAction["reportContact"] = "reportContact";
    openNativeAction["selectUsers"] = "selectUsers";
    openNativeAction["openNativeVideoNum"] = "openNativeVideoNum";
    openNativeAction["openNativeVideoChannelHome"] = "openNativeVideoChannelHome";
})(openNativeAction || (openNativeAction = {}));
//# sourceMappingURL=rong-cloud-lib.num.js.map