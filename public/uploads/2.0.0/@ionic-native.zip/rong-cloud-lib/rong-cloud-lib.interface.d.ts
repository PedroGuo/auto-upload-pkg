import { messageType, openNativeAction } from "./rong-cloud-lib.num";
export interface Conversation {
    targetId: string;
    messageType: messageType;
    latestMessageId: number;
    receivedStatus: string;
    unreadMessageCount: number;
    imageUrl: string;
    sentStatus: string;
    senderUserId: string;
    isTop: boolean;
    sentTime: number;
    receivedTime: number;
    conversationTitle: string;
    text: string;
    hasUnreadMentioned: boolean;
    conversationType: ConversationType;
    draft?: string;
    type?: string;
    isDelete?: boolean;
}
export declare enum ConversationType {
    singleChat = 1,
    discussionGroup = 2,
    Group = 3,
}
export declare enum nativeToH5 {
    openH5Page = "openH5Page",
}
export interface GetConversationListOpts {
    successCallback: (data: Conversation[]) => void;
    errorCallback: (errorMsg: string) => void;
}
export interface OpenNativeOpts {
    action: openNativeAction;
    data?: Conversation;
    successCallback: (action: nativeToH5, data: any) => void;
    errorCallback: (errMsg: string) => void;
}
export interface ReceiveMsgOpts {
    successCallback: (data: Conversation) => void;
    errorCallback: (errMsg: string) => void;
}
export interface RemoveConversationOpts {
    successCallback: () => void;
    errorCallback: (errMsg: string) => void;
    conversation: Conversation;
}
export interface SetConnectStatusOpts {
    successCallback: (status: number) => void;
    errorCallback: (errMsg: string) => void;
}
