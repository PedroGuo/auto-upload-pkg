import { IonicNativePlugin } from "@ionic-native/core";
import { GetConversationListOpts, OpenNativeOpts, ReceiveMsgOpts, RemoveConversationOpts, SetConnectStatusOpts } from "./rong-cloud-lib.interface";
export { GetConversationListOpts, OpenNativeOpts, ReceiveMsgOpts, RemoveConversationOpts, SetConnectStatusOpts } from "./rong-cloud-lib.interface";
export { messageType, openNativeAction } from "./rong-cloud-lib.num";
export declare class RongCloudLib extends IonicNativePlugin {
    getConversationList(options: GetConversationListOpts): Promise<any>;
    openNativePage(options: OpenNativeOpts): Promise<any>;
    setOnReceiveMessageListener(opts: ReceiveMsgOpts): Promise<any>;
    removeConversation(opts: RemoveConversationOpts): Promise<any>;
    setConnectionStatusListener(opts: SetConnectStatusOpts): Promise<any>;
}
