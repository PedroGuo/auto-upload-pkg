export declare enum messageType {
    txt = "txt",
    loc = "loc",
    rich = "rich",
    voc = "voc",
    img = "img",
    contact = "contact",
    other = "other",
}
export declare enum openNativeAction {
    openConversation = "openConversation",
    createGroup = "createGroup",
    addFriend = "addFriend",
    openContact = "openContact",
    createConversation = "createConversation",
    popToNative = "popToNative",
    searchText = "searchText",
    reportContact = "reportContact",
    selectUsers = "selectUsers",
    openNativeVideoNum = "openNativeVideoNum",
    openNativeVideoChannelHome = "openNativeVideoChannelHome",
}
