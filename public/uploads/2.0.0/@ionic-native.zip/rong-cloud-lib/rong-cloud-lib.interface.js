export var ConversationType;
(function (ConversationType) {
    ConversationType[ConversationType["singleChat"] = 1] = "singleChat";
    ConversationType[ConversationType["discussionGroup"] = 2] = "discussionGroup";
    ConversationType[ConversationType["Group"] = 3] = "Group";
})(ConversationType || (ConversationType = {}));
export var nativeToH5;
(function (nativeToH5) {
    nativeToH5["openH5Page"] = "openH5Page";
})(nativeToH5 || (nativeToH5 = {}));
//# sourceMappingURL=rong-cloud-lib.interface.js.map