var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from "@angular/core";
import { Cordova, IonicNativePlugin, Plugin } from "@ionic-native/core";
import { Observable } from 'rxjs/Observable';
export var SafeKeyboardType;
(function (SafeKeyboardType) {
    SafeKeyboardType[SafeKeyboardType["Number"] = 0] = "Number";
    SafeKeyboardType[SafeKeyboardType["Decimal"] = 1] = "Decimal";
    SafeKeyboardType[SafeKeyboardType["Full"] = 2] = "Full";
})(SafeKeyboardType || (SafeKeyboardType = {}));
var SafeKeyboard = (function (_super) {
    __extends(SafeKeyboard, _super);
    function SafeKeyboard() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SafeKeyboard.prototype.show = function (type, startValue) {
        return;
    };
    SafeKeyboard.prototype.close = function () { };
    SafeKeyboard.decorators = [
        { type: Injectable },
    ];
    __decorate([
        Cordova({
            successIndex: 0,
            errorIndex: 1,
            observable: true
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Number, String]),
        __metadata("design:returntype", Observable)
    ], SafeKeyboard.prototype, "show", null);
    __decorate([
        Cordova({
            sync: true
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], SafeKeyboard.prototype, "close", null);
    SafeKeyboard = __decorate([
        Plugin({
            pluginName: "Safe Keyboard",
            plugin: "com.exe.CDVSafeKeyboard",
            pluginRef: "exe.SafeKeyboard",
            platforms: ["Android", "iOS"]
        })
    ], SafeKeyboard);
    return SafeKeyboard;
}(IonicNativePlugin));
export { SafeKeyboard };
//# sourceMappingURL=index.js.map