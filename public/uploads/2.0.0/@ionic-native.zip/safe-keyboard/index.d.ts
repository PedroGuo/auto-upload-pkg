import { IonicNativePlugin } from "@ionic-native/core";
import { Observable } from 'rxjs/Observable';
export declare enum SafeKeyboardType {
    Number = 0,
    Decimal = 1,
    Full = 2,
}
export declare class SafeKeyboard extends IonicNativePlugin {
    show(type: SafeKeyboardType, startValue: string): Observable<any>;
    close(): void;
}
