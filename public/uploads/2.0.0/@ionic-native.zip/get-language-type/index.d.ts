import { IonicNativePlugin } from "@ionic-native/core";
export declare class GetLanguageType extends IonicNativePlugin {
    checktype(lanuageId: string): Promise<any>;
}
