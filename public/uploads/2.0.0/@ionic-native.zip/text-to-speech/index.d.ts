import { IonicNativePlugin } from "@ionic-native/core";
import { Observable } from 'rxjs/Observable';
export interface TTSOptions {
    /** text to speak */
    text: string;
    /** a string like 'en-US', 'zh-CN', etc */
    locale?: string;
    /** speed rate, 0 ~ 1 */
    rate?: number;
}
/**
 * @name Text To Speech
 * @description
 * Text to Speech plugin
 *
 * @usage
 * ```typescript
 * import { TextToSpeech } from '@ionic-native/text-to-speech';
 *
 * constructor(private tts: TextToSpeech) { }
 *
 * ...
 *
 * this.tts.speak('Hello World')
 *   .then(() => console.log('Success'))
 *   .catch((reason: any) => console.log(reason));
 *
 * ```
 * @interfaces
 * TTSOptions
 */
export declare class TextToSpeech extends IonicNativePlugin {
    /**
     * This function speaks
     * @param textOrOptions {string | TTSOptions} Text to speak or TTSOptions
     * @return {Observable<any>} Returns a observable that emits when the speaking finishes or pauses
     */
    speak(textOrOptions: string | TTSOptions): Observable<any>;
    /**
     * Stop any current TTS playback
     */
    stop(): void;
    /**
     * Pause any current TTS playback
     */
    pause(): void;
    /**
     * Continue current paused TTS playback
     */
    continue(): void;
    checkLanguage(): Promise<any>;
}
