var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from "@angular/core";
import { Cordova, IonicNativePlugin, Plugin } from "@ionic-native/core";
import { Observable } from 'rxjs/Observable';
/**
 * @name Text To Speech
 * @description
 * Text to Speech plugin
 *
 * @usage
 * ```typescript
 * import { TextToSpeech } from '@ionic-native/text-to-speech';
 *
 * constructor(private tts: TextToSpeech) { }
 *
 * ...
 *
 * this.tts.speak('Hello World')
 *   .then(() => console.log('Success'))
 *   .catch((reason: any) => console.log(reason));
 *
 * ```
 * @interfaces
 * TTSOptions
 */
var TextToSpeech = (function (_super) {
    __extends(TextToSpeech, _super);
    function TextToSpeech() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * This function speaks
     * @param textOrOptions {string | TTSOptions} Text to speak or TTSOptions
     * @return {Observable<any>} Returns a observable that emits when the speaking finishes or pauses
     */
    /**
       * This function speaks
       * @param textOrOptions {string | TTSOptions} Text to speak or TTSOptions
       * @return {Observable<any>} Returns a observable that emits when the speaking finishes or pauses
       */
    TextToSpeech.prototype.speak = /**
       * This function speaks
       * @param textOrOptions {string | TTSOptions} Text to speak or TTSOptions
       * @return {Observable<any>} Returns a observable that emits when the speaking finishes or pauses
       */
    function (textOrOptions) {
        return;
    };
    /**
     * Stop any current TTS playback
     */
    /**
       * Stop any current TTS playback
       */
    TextToSpeech.prototype.stop = /**
       * Stop any current TTS playback
       */
    function () { };
    /**
     * Pause any current TTS playback
     */
    /**
       * Pause any current TTS playback
       */
    TextToSpeech.prototype.pause = /**
       * Pause any current TTS playback
       */
    function () { };
    /**
     * Continue current paused TTS playback
     */
    /**
       * Continue current paused TTS playback
       */
    TextToSpeech.prototype.continue = /**
       * Continue current paused TTS playback
       */
    function () { };
    TextToSpeech.prototype.checkLanguage = function () {
        return;
    };
    TextToSpeech.decorators = [
        { type: Injectable },
    ];
    __decorate([
        Cordova({
            successIndex: 1,
            errorIndex: 2,
            observable: true
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Observable)
    ], TextToSpeech.prototype, "speak", null);
    __decorate([
        Cordova({
            sync: true
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], TextToSpeech.prototype, "stop", null);
    __decorate([
        Cordova({
            sync: true
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], TextToSpeech.prototype, "pause", null);
    __decorate([
        Cordova({
            sync: true
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", void 0)
    ], TextToSpeech.prototype, "continue", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], TextToSpeech.prototype, "checkLanguage", null);
    /**
     * @name Text To Speech
     * @description
     * Text to Speech plugin
     *
     * @usage
     * ```typescript
     * import { TextToSpeech } from '@ionic-native/text-to-speech';
     *
     * constructor(private tts: TextToSpeech) { }
     *
     * ...
     *
     * this.tts.speak('Hello World')
     *   .then(() => console.log('Success'))
     *   .catch((reason: any) => console.log(reason));
     *
     * ```
     * @interfaces
     * TTSOptions
     */
    TextToSpeech = __decorate([
        Plugin({
            pluginName: "Text To Speech",
            plugin: "cordova-plugin-tts",
            pluginRef: "TTS",
            repo: "https://github.com/vilic/cordova-plugin-tts",
            platforms: ["Android", "iOS", "Windows Phone 8"]
        })
    ], TextToSpeech);
    return TextToSpeech;
}(IonicNativePlugin));
export { TextToSpeech };
//# sourceMappingURL=index.js.map