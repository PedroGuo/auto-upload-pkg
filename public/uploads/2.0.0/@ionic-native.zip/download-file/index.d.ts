import { IonicNativePlugin } from "@ionic-native/core";
export interface DownLoadOpt {
    id: string;
    detailId: string;
    url?: string;
    downloadUrl?: string;
    fileId: string;
    fileName: string;
    isEncryption: boolean;
    playToken: string;
    isBaiDu: boolean;
    length: number;
}
export declare class DownloadFile extends IonicNativePlugin {
    startDownLoad(downloadOpts: DownLoadOpt[], success: Function, error: Function): void;
    pauseDownLoad(downloadOpts: DownLoadOpt[]): void;
    cancelDownLoad(downloadOpts: DownLoadOpt[]): void;
    getDownloadListProgress(downloadOpts: DownLoadOpt[], success: Function): void;
}
