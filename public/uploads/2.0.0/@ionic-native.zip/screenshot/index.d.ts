import { IonicNativePlugin } from "@ionic-native/core";
import { Observable } from "rxjs/Observable";
export interface ScreenShotResponse {
    status: number;
    msg?: string;
    path: string;
}
export declare class ScreenShot extends IonicNativePlugin {
    onScreenShot(): Observable<ScreenShotResponse>;
}
