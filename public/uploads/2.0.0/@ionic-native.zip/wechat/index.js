var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from "@angular/core";
import { Cordova, IonicNativePlugin, Plugin } from "@ionic-native/core";
// https://github.com/xu-li/cordova-plugin-wechat/blob/develop/www/wechat.js
// https://github.com/xu-li/cordova-plugin-wechat/blob/develop/www/wechat.js
export var Scene;
// https://github.com/xu-li/cordova-plugin-wechat/blob/develop/www/wechat.js
(function (Scene) {
    Scene[Scene["SESSION"] = 0] = "SESSION";
    Scene[Scene["TIMELINE"] = 1] = "TIMELINE";
    Scene[Scene["FAVORITE"] = 2] = "FAVORITE"; // 收藏
})(Scene || (Scene = {}));
export var Type;
(function (Type) {
    Type[Type["APP"] = 1] = "APP";
    Type[Type["EMOTION"] = 2] = "EMOTION";
    Type[Type["FILE"] = 3] = "FILE";
    Type[Type["IMAGE"] = 4] = "IMAGE";
    Type[Type["MUSIC"] = 5] = "MUSIC";
    Type[Type["VIDEO"] = 6] = "VIDEO";
    Type[Type["WEBPAGE"] = 7] = "WEBPAGE";
})(Type || (Type = {}));
var WeChat = (function (_super) {
    __extends(WeChat, _super);
    function WeChat() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 分享微信场景
        _this.Scene = {
            appMessage: 0,
            timeline: 1,
            collection: 2
        };
        // 分享微信类型
        _this.Type = {
            APP: 1,
            EMOTION: 2,
            FILE: 3,
            IMAGE: 4,
            MUSIC: 5,
            VIDEO: 6,
            WEBPAGE: 7
        };
        return _this;
    }
    // 判断是否下载微信
    // 判断是否下载微信
    WeChat.prototype.isInstalled = 
    // 判断是否下载微信
    function () {
        return;
    };
    // Share a message to wechat app
    // Share a message to wechat app
    WeChat.prototype.share = 
    // Share a message to wechat app
    function (message, success, fail) {
        return;
    };
    // Share a message to wechat app
    // Share a message to wechat app
    WeChat.prototype.openMiniProgram = 
    // Share a message to wechat app
    function (message, success, fail) {
        return;
    };
    // Sending an auth request to wechat
    // Sending an auth request to wechat
    WeChat.prototype.auth = 
    // Sending an auth request to wechat
    function (scope, state) {
        return;
    };
    // Send a payment request
    // Send a payment request
    WeChat.prototype.sendPaymentRequest = 
    // Send a payment request
    function (params) {
        return;
    };
    // Jump to Official Accounts
    // Jump to Official Accounts
    WeChat.prototype.jumpToBizProfile = 
    // Jump to Official Accounts
    function (params) {
        return;
    };
    // Jump to wechat
    // Jump to wechat
    WeChat.prototype.jumpToWechat = 
    // Jump to wechat
    function (url) {
        return;
    };
    WeChat.decorators = [
        { type: Injectable },
    ];
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], WeChat.prototype, "isInstalled", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Function, Function]),
        __metadata("design:returntype", Promise)
    ], WeChat.prototype, "share", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Function, Function]),
        __metadata("design:returntype", Promise)
    ], WeChat.prototype, "openMiniProgram", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Object]),
        __metadata("design:returntype", Promise)
    ], WeChat.prototype, "auth", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], WeChat.prototype, "sendPaymentRequest", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], WeChat.prototype, "jumpToBizProfile", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String]),
        __metadata("design:returntype", Promise)
    ], WeChat.prototype, "jumpToWechat", null);
    WeChat = __decorate([
        Plugin({
            pluginName: "WeChat",
            plugin: "cordova-plugin-wechat",
            // pluginRef: "Wechat",
            pluginRef: "exe.Wechat",
            repo: "https://github.com/xu-li/cordova-plugin-wechat",
            install: "cordova plugin add cordova-plugin-wechat --variable wechatappid=YOUR_WECHAT_APPID",
            installVariables: ["wechatappid"],
            platforms: ["Android", "iOS"]
        })
    ], WeChat);
    return WeChat;
}(IonicNativePlugin));
export { WeChat };
//# sourceMappingURL=index.js.map