import { IonicNativePlugin } from "@ionic-native/core";
export declare class DualMessageChannel extends IonicNativePlugin {
    /**
     * 订阅原生消息通道
     * 实现 Native -> Web 消息传递
     */
    postMessage(params: object, onSuccess: Function, onError: Function): void;
}
