import { IonicNativePlugin } from "@ionic-native/core";
import { Observable } from "rxjs/Observable";
/**
 * It is a Apache Cordova plugin to simplify handling phone call
 * status and events in Android devices.
 * Supported platforms —— Android 2.3.3 or higher
 *
 * @export
 * @class PhoneCalltrap
 * @extends {IonicNativePlugin}
 */
export declare class PhoneCalltrap extends IonicNativePlugin {
    onCall(): Observable<any>;
}
