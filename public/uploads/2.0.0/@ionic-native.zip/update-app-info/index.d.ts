import { IonicNativePlugin } from "@ionic-native/core";
export declare class UpdateAppInfo extends IonicNativePlugin {
    checkUpdate(tenantId: string): Promise<any>;
    updateTenant(tenantId: string): Promise<any>;
    upgradeHtml(include_disable: any): Promise<any>;
}
