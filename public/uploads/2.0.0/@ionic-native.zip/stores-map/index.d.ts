import { IonicNativePlugin } from "@ionic-native/core";
export interface SimpleLocation {
    longitude: number;
    latitude: number;
}
export interface StoresMapResult {
    type: "enterStores" | "searchStores" | "close";
    store_id?: string;
}
export declare class StoresMap extends IonicNativePlugin {
    openStoresMap(options: object): Promise<StoresMapResult>;
    enterStoresMapBack(options: SimpleLocation): Promise<StoresMapResult>;
    routeMapPath(options: SimpleLocation): void;
}
