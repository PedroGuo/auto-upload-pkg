import { IonicNativePlugin } from "@ionic-native/core";
export declare class SpeechRecognition extends IonicNativePlugin {
    recognition(onSuccess: Function, onError: Function): Promise<any>;
}
