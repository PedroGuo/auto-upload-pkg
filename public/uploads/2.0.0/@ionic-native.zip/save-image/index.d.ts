import { IonicNativePlugin } from "@ionic-native/core";
export declare class SaveImage extends IonicNativePlugin {
    saveImageToLibrary(imgUrl: string, callBack: Function, errorCallBack: Function): void;
}
