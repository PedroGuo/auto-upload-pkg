import { IonicNativePlugin } from "@ionic-native/core";
export interface RecognizeOptions {
    lengthLimit?: number;
    lengthLimitMin?: number;
}
export interface RecognizeResult {
    url: string;
    text?: string;
    isSuccess: boolean;
    errorMessage?: string;
}
export declare class SoundRecognition extends IonicNativePlugin {
    startRecognition(options: RecognizeOptions): Promise<RecognizeResult>;
    stopRecognition(): void;
    cancelRecognition(): void;
}
