import { IonicNativePlugin } from "@ionic-native/core";
export interface ShareTextOption {
    text: string;
}
export interface ShareImageOption {
    imageURL: string;
}
export interface ShareWebOption {
    type?: number;
    title: string;
    pageURL: string;
    thumbURL: string;
    messageDescription: string;
}
export interface ShareEmbedOptions {
    type: number;
    url: string;
    title: string;
    content: string;
    image: string;
}
/**
 * @name DingTalk
 * @description
 * This plugin does something
 *
 * @usage
 * ```typescript
 * import { Dingtalk } from '@ionic-native/dingtalk';
 *
 *
 * constructor(private dingtalk: Dingtalk) { }
 *
 * ...
 *
 *
 * this.dingtalk.functionName('Hello', 123)
 *   .then((res: any) => console.log(res))
 *   .catch((error: any) => console.error(error));
 *
 * ```
 */
export declare class DingTalk extends IonicNativePlugin {
    isInstalled(): Promise<boolean>;
    shareTextObject(option: ShareTextOption): Promise<boolean>;
    shareImageObject(option: ShareImageOption): Promise<boolean>;
    shareWebObject(option: ShareWebOption | ShareEmbedOptions): Promise<boolean>;
}
