var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@angular/core';
import { Cordova, CordovaCheck, CordovaProperty, IonicNativePlugin, Plugin } from '@ionic-native/core';
import { Observable } from 'rxjs/Observable';
import { merge } from 'rxjs/observable/merge';
export var Connection;
(function (Connection) {
    Connection[Connection["UNKNOWN"] = 0] = "UNKNOWN";
    Connection[Connection["ETHERNET"] = 1] = "ETHERNET";
    Connection[Connection["WIFI"] = 2] = "WIFI";
    Connection[Connection["CELL_2G"] = 3] = "CELL_2G";
    Connection[Connection["CELL_3G"] = 4] = "CELL_3G";
    Connection[Connection["CELL_4G"] = 5] = "CELL_4G";
    Connection[Connection["CELL"] = 6] = "CELL";
    Connection[Connection["NONE"] = 7] = "NONE";
})(Connection || (Connection = {}));
/**
 * @name Network
 * @description
 * Requires Cordova plugin: cordova-plugin-network-information. For more info, please see the [Network plugin docs](https://github.com/apache/cordova-plugin-network-information).
 *
 * @usage
 * ```typescript
 * import { Network } from '@ionic-native/network';
 *
 * constructor(private network: Network) { }
 *
 * ...
 *
 * // watch network for a disconnection
 * let disconnectSubscription = this.network.onDisconnect().subscribe(() => {
 *   console.log('network was disconnected :-(');
 * });
 *
 * // stop disconnect watch
 * disconnectSubscription.unsubscribe();
 *
 *
 * // watch network for a connection
 * let connectSubscription = this.network.onConnect().subscribe(() => {
 *   console.log('network connected!');
 *   // We just got a connection but we need to wait briefly
 *    // before we determine the connection type. Might need to wait.
 *   // prior to doing any api requests as well.
 *   setTimeout(() => {
 *     if (this.network.type === 'wifi') {
 *       console.log('we got a wifi connection, woohoo!');
 *     }
 *   }, 3000);
 * });
 *
 * // stop connect watch
 * connectSubscription.unsubscribe();
 *
 * ```
 * @advanced
 * The `type` property will return one of the following connection types: `unknown`, `ethernet`, `wifi`, `2g`, `3g`, `4g`, `cellular`, `none`
 */
var Network = (function (_super) {
    __extends(Network, _super);
    function Network() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**
           * Constants for possible connection types
           */
        _this.Connection = {
            UNKNOWN: 'unknown',
            ETHERNET: 'ethernet',
            WIFI: 'wifi',
            CELL_2G: '2g',
            CELL_3G: '3g',
            CELL_4G: '4g',
            CELL: 'cellular',
            NONE: 'none'
        };
        return _this;
    }
    /**
     * Returns an observable to watch connection changes
     * @return {Observable<any>}
     */
    /**
       * Returns an observable to watch connection changes
       * @return {Observable<any>}
       */
    Network.prototype.onchange = /**
       * Returns an observable to watch connection changes
       * @return {Observable<any>}
       */
    function () {
        return merge(this.onConnect(), this.onDisconnect());
    };
    /**
     * Get notified when the device goes offline
     * @returns {Observable<any>} Returns an observable.
     */
    /**
       * Get notified when the device goes offline
       * @returns {Observable<any>} Returns an observable.
       */
    Network.prototype.onDisconnect = /**
       * Get notified when the device goes offline
       * @returns {Observable<any>} Returns an observable.
       */
    function () {
        return;
    };
    /**
     * Get notified when the device goes online
     * @returns {Observable<any>} Returns an observable.
     */
    /**
       * Get notified when the device goes online
       * @returns {Observable<any>} Returns an observable.
       */
    Network.prototype.onConnect = /**
       * Get notified when the device goes online
       * @returns {Observable<any>} Returns an observable.
       */
    function () {
        return;
    };
    Network.decorators = [
        { type: Injectable },
    ];
    __decorate([
        CordovaProperty,
        __metadata("design:type", String)
    ], Network.prototype, "type", void 0);
    __decorate([
        CordovaProperty,
        __metadata("design:type", String)
    ], Network.prototype, "downlinkMax", void 0);
    __decorate([
        CordovaCheck(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Observable)
    ], Network.prototype, "onchange", null);
    __decorate([
        Cordova({
            eventObservable: true,
            event: 'offline',
            element: document
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Observable)
    ], Network.prototype, "onDisconnect", null);
    __decorate([
        Cordova({
            eventObservable: true,
            event: 'online',
            element: document
        }),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Observable)
    ], Network.prototype, "onConnect", null);
    /**
     * @name Network
     * @description
     * Requires Cordova plugin: cordova-plugin-network-information. For more info, please see the [Network plugin docs](https://github.com/apache/cordova-plugin-network-information).
     *
     * @usage
     * ```typescript
     * import { Network } from '@ionic-native/network';
     *
     * constructor(private network: Network) { }
     *
     * ...
     *
     * // watch network for a disconnection
     * let disconnectSubscription = this.network.onDisconnect().subscribe(() => {
     *   console.log('network was disconnected :-(');
     * });
     *
     * // stop disconnect watch
     * disconnectSubscription.unsubscribe();
     *
     *
     * // watch network for a connection
     * let connectSubscription = this.network.onConnect().subscribe(() => {
     *   console.log('network connected!');
     *   // We just got a connection but we need to wait briefly
     *    // before we determine the connection type. Might need to wait.
     *   // prior to doing any api requests as well.
     *   setTimeout(() => {
     *     if (this.network.type === 'wifi') {
     *       console.log('we got a wifi connection, woohoo!');
     *     }
     *   }, 3000);
     * });
     *
     * // stop connect watch
     * connectSubscription.unsubscribe();
     *
     * ```
     * @advanced
     * The `type` property will return one of the following connection types: `unknown`, `ethernet`, `wifi`, `2g`, `3g`, `4g`, `cellular`, `none`
     */
    Network = __decorate([
        Plugin({
            pluginName: 'Network',
            plugin: 'cordova-plugin-network-information',
            // pluginRef: 'navigator.connection',
            pluginRef: 'exe.Network',
            repo: 'https://github.com/apache/cordova-plugin-network-information',
            platforms: ['Amazon Fire OS', 'Android', 'Browser', 'iOS', 'Windows']
        })
    ], Network);
    return Network;
}(IonicNativePlugin));
export { Network };
//# sourceMappingURL=index.js.map