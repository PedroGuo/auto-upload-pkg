import { IonicNativePlugin } from "@ionic-native/core";
export interface ShowPhotosParams {
    index: number;
    images: string[];
    watermark?: {
        userId: string;
        userName: string;
    };
    canImageSave: boolean;
    needStatistics?: boolean;
    fileId?: string;
    courseId?: string;
    courseName?: string;
    courseWareId?: string;
    courseWareName?: string;
    learnType?: number;
    fromType?: number;
    fromId?: string | number;
}
export declare class PhotoViewer extends IonicNativePlugin {
    showPhotos(message: ShowPhotosParams, callback?: Function): Promise<any>;
}
