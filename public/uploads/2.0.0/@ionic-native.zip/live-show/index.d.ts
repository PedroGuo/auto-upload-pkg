import { IonicNativePlugin } from "@ionic-native/core";
export interface LiveConfig {
    token: string;
    tenantId: string;
    userId: string;
    userName: string;
    apiUrl: string;
    liveUrl: string;
}
export declare class LiveShow extends IonicNativePlugin {
    init(config: LiveConfig): void;
    play(data: any): void;
    publish(zoom: object, data: any, callback: Function): void;
    quit(): Promise<any>;
    servieQuit(params: any): Promise<any>;
    refreshDoc(params: any): Promise<any>;
}
