import { IonicNativePlugin } from "@ionic-native/core";
export interface AnyObject {
    [key: string]: any;
}
export interface WriteArticleOptions {
    fromType: string;
    draftId: number | string;
    token: string;
    communities: AnyObject[];
    sysParams: AnyObject;
    topicConig?: RichTextTopicConfig;
}
export interface WriteArticleResult {
    event: 'postArticle' | 'saveDraft' | 'deleteDraft';
    data?: AnyObject;
}
export interface RichTextTopicConfig {
    useTopic: boolean;
    startTopicId?: number;
    startTopicName?: string;
    topicTypes?: number[];
}
export declare class RichText extends IonicNativePlugin {
    writeArticle(options: WriteArticleOptions): Promise<WriteArticleResult>;
    exitWriting(message: string): Promise<any>;
}
