var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from "@angular/core";
import { Cordova, IonicNativePlugin, Plugin } from "@ionic-native/core";
export var OrientationType;
(function (OrientationType) {
    OrientationType[OrientationType["portrait"] = 0] = "portrait";
    OrientationType[OrientationType["auto"] = 1] = "auto";
    OrientationType[OrientationType["landscape"] = 2] = "landscape";
})(OrientationType || (OrientationType = {}));
var AppPlatform = (function (_super) {
    __extends(AppPlatform, _super);
    function AppPlatform() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * Check Installed Apps
     * iOS:应用scheme;Android:应用包名
     *
     * @returns {Promise<string>}
     */
    /**
       * Check Installed Apps
       * iOS:应用scheme;Android:应用包名
       *
       * @returns {Promise<string>}
       */
    AppPlatform.prototype.checkInstalledApps = /**
       * Check Installed Apps
       * iOS:应用scheme;Android:应用包名
       *
       * @returns {Promise<string>}
       */
    function (appName) {
        return;
    };
    /**
     * Close the embeded webview
     * @returns {Promise<string>}
     */
    /**
       * Close the embeded webview
       * @returns {Promise<string>}
       */
    AppPlatform.prototype.close = /**
       * Close the embeded webview
       * @returns {Promise<string>}
       */
    function () {
        return;
    };
    /**
     * Launch specific app
     * @returns {Promise<string | number>}
     */
    /**
       * Launch specific app
       * @returns {Promise<string | number>}
       */
    AppPlatform.prototype.launchApp = /**
       * Launch specific app
       * @returns {Promise<string | number>}
       */
    function (options) {
        return;
    };
    /**
     * Open specific url link
     * @returns {Promise<string>}
     */
    /**
       * Open specific url link
       * @returns {Promise<string>}
       */
    AppPlatform.prototype.openLink = /**
       * Open specific url link
       * @returns {Promise<string>}
       */
    function (options) {
        return;
    };
    /**
     * Toggle navbar display status
     * @returns {Promise<string>}
     */
    /**
       * Toggle navbar display status
       * @returns {Promise<string>}
       */
    AppPlatform.prototype.toggleNavBar = /**
       * Toggle navbar display status
       * @returns {Promise<string>}
       */
    function (showNav) {
        return;
    };
    /**
     * Config navbar
     * @returns {Promise<string>}
     */
    /**
       * Config navbar
       * @returns {Promise<string>}
       */
    AppPlatform.prototype.configNavBar = /**
       * Config navbar
       * @returns {Promise<string>}
       */
    function (options) {
        return;
    };
    /**
     * 某些页面没有返回键，显示浮动按钮为了返回，主要针对苹果设备
     * 备注：目前仅对接美云智数平台
     * @param showFloat
     */
    /**
       * 某些页面没有返回键，显示浮动按钮为了返回，主要针对苹果设备
       * 备注：目前仅对接美云智数平台
       * @param showFloat
       */
    AppPlatform.prototype.toggleFloatButton = /**
       * 某些页面没有返回键，显示浮动按钮为了返回，主要针对苹果设备
       * 备注：目前仅对接美云智数平台
       * @param showFloat
       */
    function (showFloat) {
        return;
    };
    /**
     * 获取尺寸信息
     * 备注：目前仅对接美云智数平台
     * @param type - webview/screen
     */
    /**
       * 获取尺寸信息
       * 备注：目前仅对接美云智数平台
       * @param type - webview/screen
       */
    AppPlatform.prototype.getDimensions = /**
       * 获取尺寸信息
       * 备注：目前仅对接美云智数平台
       * @param type - webview/screen
       */
    function (type) {
        return;
    };
    /**
     * 开启手机横屏或竖屏显示
     * 备注：目前仅对接美云智数平台
     * @param enable
     */
    /**
       * 开启手机横屏或竖屏显示
       * 备注：目前仅对接美云智数平台
       * @param enable
       */
    AppPlatform.prototype.setOrientation = /**
       * 开启手机横屏或竖屏显示
       * 备注：目前仅对接美云智数平台
       * @param enable
       */
    function (enable) {
        return;
    };
    /**
     * 将数据存储在本地缓存中指定的key中，会覆盖掉原来该key对应的内容。
     * 备注：目前仅对接美云智数平台
     * @param key
     * @param value
     */
    /**
       * 将数据存储在本地缓存中指定的key中，会覆盖掉原来该key对应的内容。
       * 备注：目前仅对接美云智数平台
       * @param key
       * @param value
       */
    AppPlatform.prototype.setStorage = /**
       * 将数据存储在本地缓存中指定的key中，会覆盖掉原来该key对应的内容。
       * 备注：目前仅对接美云智数平台
       * @param key
       * @param value
       */
    function (key, value) {
        return;
    };
    /**
     * 从本地缓存中异步获取指定key的内容
     * 备注：目前仅对接美云智数平台
     * @param key
     */
    /**
       * 从本地缓存中异步获取指定key的内容
       * 备注：目前仅对接美云智数平台
       * @param key
       */
    AppPlatform.prototype.getStorage = /**
       * 从本地缓存中异步获取指定key的内容
       * 备注：目前仅对接美云智数平台
       * @param key
       */
    function (key) {
        return;
    };
    /**
     * 通过获取文档的mimeType，调用系统的app打开对应的应用
     * 备注：目前仅对接美云智数平台
     * @param options
     */
    /**
       * 通过获取文档的mimeType，调用系统的app打开对应的应用
       * 备注：目前仅对接美云智数平台
       * @param options
       */
    AppPlatform.prototype.openDocument = /**
       * 通过获取文档的mimeType，调用系统的app打开对应的应用
       * 备注：目前仅对接美云智数平台
       * @param options
       */
    function (options) {
        return;
    };
    /**
     * 播放视频或音频
     * @param options
     */
    /**
       * 播放视频或音频
       * @param options
       */
    AppPlatform.prototype.playMedia = /**
       * 播放视频或音频
       * @param options
       */
    function (options) {
        return;
    };
    /**
     * 播放视频或音频
     * @param options
     */
    /**
       * 播放视频或音频
       * @param options
       */
    AppPlatform.prototype.auth = /**
       * 播放视频或音频
       * @param options
       */
    function (options) {
        return;
    };
    AppPlatform.decorators = [
        { type: Injectable },
    ];
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "checkInstalledApps", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "close", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "launchApp", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "openLink", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Boolean]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "toggleNavBar", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "configNavBar", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Boolean]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "toggleFloatButton", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "getDimensions", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Boolean]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "setOrientation", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String, String]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "setStorage", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [String]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "getStorage", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "openDocument", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "playMedia", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object]),
        __metadata("design:returntype", Promise)
    ], AppPlatform.prototype, "auth", null);
    AppPlatform = __decorate([
        Plugin({
            pluginName: "AppPlatform",
            plugin: "cordova-plugin-app-platform",
            pluginRef: "exe.AppPlatform",
            platforms: ["Android", "iOS", "Embeded"]
        })
    ], AppPlatform);
    return AppPlatform;
}(IonicNativePlugin));
export { AppPlatform };
//# sourceMappingURL=index.js.map