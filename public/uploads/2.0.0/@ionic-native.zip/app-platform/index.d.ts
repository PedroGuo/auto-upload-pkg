import { IonicNativePlugin } from "@ionic-native/core";
export declare enum OrientationType {
    portrait = 0,
    auto = 1,
    landscape = 2,
}
export interface OpenLinkOptions {
    url: string;
    orientation?: OrientationType;
    target?: string;
    title?: string;
    headerStyle?: string | number;
}
export interface LaunchAppOptions {
    appName: string;
    downloadUrl?: string;
    activity?: string;
}
export interface NavbarOptions {
    statusBarColor?: number;
}
export interface OpenDocumentOptions {
    fileType?: string;
    filePath: string;
}
export interface PlayMediaOptions {
    url: string;
    type?: string;
    filename?: string;
}
export declare class AppPlatform extends IonicNativePlugin {
    /**
     * Check Installed Apps
     * iOS:应用scheme;Android:应用包名
     *
     * @returns {Promise<string>}
     */
    checkInstalledApps(appName: string): Promise<string>;
    /**
     * Close the embeded webview
     * @returns {Promise<string>}
     */
    close(): Promise<string>;
    /**
     * Launch specific app
     * @returns {Promise<string | number>}
     */
    launchApp(options: LaunchAppOptions): Promise<string | number>;
    /**
     * Open specific url link
     * @returns {Promise<string>}
     */
    openLink(options: OpenLinkOptions): Promise<string>;
    /**
     * Toggle navbar display status
     * @returns {Promise<string>}
     */
    toggleNavBar(showNav: boolean): Promise<string>;
    /**
     * Config navbar
     * @returns {Promise<string>}
     */
    configNavBar(options: NavbarOptions): Promise<string>;
    /**
     * 某些页面没有返回键，显示浮动按钮为了返回，主要针对苹果设备
     * 备注：目前仅对接美云智数平台
     * @param showFloat
     */
    toggleFloatButton(showFloat: boolean): Promise<any>;
    /**
     * 获取尺寸信息
     * 备注：目前仅对接美云智数平台
     * @param type - webview/screen
     */
    getDimensions(type: string): Promise<object>;
    /**
     * 开启手机横屏或竖屏显示
     * 备注：目前仅对接美云智数平台
     * @param enable
     */
    setOrientation(enable: boolean): Promise<any>;
    /**
     * 将数据存储在本地缓存中指定的key中，会覆盖掉原来该key对应的内容。
     * 备注：目前仅对接美云智数平台
     * @param key
     * @param value
     */
    setStorage(key: string, value: string): Promise<any>;
    /**
     * 从本地缓存中异步获取指定key的内容
     * 备注：目前仅对接美云智数平台
     * @param key
     */
    getStorage(key: string): Promise<string>;
    /**
     * 通过获取文档的mimeType，调用系统的app打开对应的应用
     * 备注：目前仅对接美云智数平台
     * @param options
     */
    openDocument(options: OpenDocumentOptions): Promise<any>;
    /**
     * 播放视频或音频
     * @param options
     */
    playMedia(options: PlayMediaOptions): Promise<any>;
    /**
     * 播放视频或音频
     * @param options
     */
    auth(options: any): Promise<any>;
}
