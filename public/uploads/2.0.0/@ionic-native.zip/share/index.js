var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from "@angular/core";
import { Cordova, IonicNativePlugin, Plugin } from "@ionic-native/core";
export var Scene;
(function (Scene) {
    Scene[Scene["SESSION"] = 0] = "SESSION";
    Scene[Scene["TIMELINE"] = 1] = "TIMELINE";
    Scene[Scene["FAVORITE"] = 2] = "FAVORITE"; // 收藏
})(Scene || (Scene = {}));
export var Type;
(function (Type) {
    Type[Type["APP"] = 1] = "APP";
    Type[Type["EMOTION"] = 2] = "EMOTION";
    Type[Type["FILE"] = 3] = "FILE";
    Type[Type["IMAGE"] = 4] = "IMAGE";
    Type[Type["MUSIC"] = 5] = "MUSIC";
    Type[Type["VIDEO"] = 6] = "VIDEO";
    Type[Type["WEBPAGE"] = 7] = "WEBPAGE";
})(Type || (Type = {}));
var Share = (function (_super) {
    __extends(Share, _super);
    function Share() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // 分享场景
        _this.Scene = {
            appMessage: 0,
            timeline: 1,
            collection: 2
        };
        // 分享类型
        _this.Type = {
            APP: 1,
            EMOTION: 2,
            FILE: 3,
            IMAGE: 4,
            MUSIC: 5,
            VIDEO: 6,
            WEBPAGE: 7
        };
        return _this;
    }
    // 判断是否下载
    // 判断是否下载
    Share.prototype.isInstalled = 
    // 判断是否下载
    function () {
        return;
    };
    Share.prototype.share = function (message, success, fail) {
        return;
    };
    Share.prototype.auth = function (scope, state) {
        return;
    };
    Share.decorators = [
        { type: Injectable },
    ];
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", []),
        __metadata("design:returntype", Promise)
    ], Share.prototype, "isInstalled", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Function, Function]),
        __metadata("design:returntype", Promise)
    ], Share.prototype, "share", null);
    __decorate([
        Cordova(),
        __metadata("design:type", Function),
        __metadata("design:paramtypes", [Object, Object]),
        __metadata("design:returntype", Promise)
    ], Share.prototype, "auth", null);
    Share = __decorate([
        Plugin({
            pluginName: "Share",
            plugin: "cordova-plugin-share",
            // pluginRef: "share",
            pluginRef: "exe.Share",
            repo: "",
            platforms: ["Android", "iOS"]
        })
    ], Share);
    return Share;
}(IonicNativePlugin));
export { Share };
//# sourceMappingURL=index.js.map