import { IonicNativePlugin } from "@ionic-native/core";
export declare enum Scene {
    SESSION = 0,
    TIMELINE = 1,
    FAVORITE = 2,
}
export declare enum Type {
    APP = 1,
    EMOTION = 2,
    FILE = 3,
    IMAGE = 4,
    MUSIC = 5,
    VIDEO = 6,
    WEBPAGE = 7,
}
export interface MediaType {
    type?: Type;
    webpageUrl?: string;
    image?: string;
    musicUrl?: string;
    musicDataUrl?: string;
    videoUrl?: string;
    extInfo?: string;
    url?: string;
    emotion?: string;
    file?: string;
}
export interface ShareMessageOptions {
    title?: string;
    description?: string;
    mediaTagName?: string;
    thumb?: string;
    media?: MediaType;
}
export interface ShareOptions {
    text?: string;
    message: ShareMessageOptions;
    scene: Scene;
}
export declare class Share extends IonicNativePlugin {
    Scene: {
        appMessage: number;
        timeline: number;
        collection: number;
    };
    Type: {
        APP: number;
        EMOTION: number;
        FILE: number;
        IMAGE: number;
        MUSIC: number;
        VIDEO: number;
        WEBPAGE: number;
    };
    isInstalled(): Promise<any>;
    share(message: ShareOptions, success?: Function, fail?: Function): Promise<any>;
    auth(scope: any, state: any): Promise<any>;
}
