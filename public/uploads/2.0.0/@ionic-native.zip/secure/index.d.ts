import { IonicNativePlugin } from "@ionic-native/core";
export declare class Secure extends IonicNativePlugin {
    setScreenShots(enable: boolean): void;
}
