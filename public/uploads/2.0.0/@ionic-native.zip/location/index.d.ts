import { IonicNativePlugin } from "@ionic-native/core";
import { Observable } from "rxjs/Observable";
export interface GeolocationOptions {
    maximumAge?: number;
    timeout?: number;
    enableHighAccuracy?: boolean;
    useNativePopup?: boolean;
}
export interface ContinuedLocationOptions {
    timeInterval?: number;
    distanceFilter?: number;
    locationTimeout?: number;
    enableLowAccuracy?: boolean;
}
export interface LocationInfo {
    coords: {
        longitude: number;
        latitude: number;
        address?: string;
    };
    regeocode: {
        adcode: string;
        city: string;
        citycode: string;
        country: string;
        district: string;
        province: string;
    };
    timestamp: number;
}
export declare class Location extends IonicNativePlugin {
    getCurrentPosition(options?: GeolocationOptions): Promise<LocationInfo>;
    startContinuedLocation(options: ContinuedLocationOptions): Observable<LocationInfo>;
    stopContinuedLocation(): Promise<any>;
}
