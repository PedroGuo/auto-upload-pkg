export declare function checkReady(): void;
